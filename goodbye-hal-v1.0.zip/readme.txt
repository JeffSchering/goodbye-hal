=== Goodbye HAL ===
Contributors: jeffsch 
Tags: hello, dolly, admin, goodbye, hal
Requires at least: 3.0  
Stable tag: 1.0  
Tested up to: 4.5.3
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Based on Hello Dolly by Matt Mullenweg, Goodbye HAL displays lyrics from the song Daisy Bell, which HAL sang in 2001: A Space Odyssey.

== Description ==

Daisy, Daisy, I'm half crazy, all for the love of you.

This is not just a Wordpress plugin. It's based on the famous plugin [Hello Dolly](http://wordpress.org/extend/plugins/hello-dolly/) by Matt Mullenweg, and works just like it except that the lyrics are for the song Daisy Bell, which [HAL 9000](https://en.wikipedia.org/wiki/HAL_9000) sang as he was being de-activated in the movie <cite>2001: A Space Odyssey</cite>.

When this plugin is activated, you'll see a random line from the Daisy Bell lyrics in the upper right of your admin screen.

